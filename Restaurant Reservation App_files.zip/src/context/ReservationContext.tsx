import  { createContext, useContext, useState, ReactNode } from 'react';

export type Reservation = {
  date: string;
  time: string;
  guests: number;
  name: string;
  email: string;
  phone: string;
  specialRequests?: string;
};

type ReservationContextType = {
  reservation: Reservation;
  updateReservation: (data: Partial<Reservation>) => void;
  clearReservation: () => void;
  reservations: Reservation[];
  addReservation: (data: Reservation) => void;
};

const defaultReservation: Reservation = {
  date: '',
  time: '',
  guests: 2,
  name: '',
  email: '',
  phone: '',
  specialRequests: '',
};

const ReservationContext = createContext<ReservationContextType | undefined>(undefined);

export function ReservationProvider({ children }: { children: ReactNode }) {
  const [reservation, setReservation] = useState<Reservation>(defaultReservation);
  const [reservations, setReservations] = useState<Reservation[]>([]);

  const updateReservation = (data: Partial<Reservation>) => {
    setReservation(prev => ({ ...prev, ...data }));
  };

  const clearReservation = () => {
    setReservation(defaultReservation);
  };

  const addReservation = (data: Reservation) => {
    setReservations(prev => [...prev, data]);
  };

  return (
    <ReservationContext.Provider value={{ 
      reservation, 
      updateReservation, 
      clearReservation,
      reservations,
      addReservation
    }}>
      {children}
    </ReservationContext.Provider>
  );
}

export function useReservation() {
  const context = useContext(ReservationContext);
  if (context === undefined) {
    throw new Error('useReservation must be used within a ReservationProvider');
  }
  return context;
}
 