import  { Routes, Route } from 'react-router-dom';
import Layout from './components/Layout';
import Home from './pages/Home';
import Reserve from './pages/Reserve';
import Confirmation from './pages/Confirmation';
import { ReservationProvider } from './context/ReservationContext';

function App() {
  return (
    <ReservationProvider>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<Home />} />
          <Route path="reserve" element={<Reserve />} />
          <Route path="confirmation" element={<Confirmation />} />
        </Route>
      </Routes>
    </ReservationProvider>
  );
}

export default App;
 