import  { useState } from 'react';
import { Link } from 'react-router-dom';
import { Menu, X, Coffee } from 'lucide-react';

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  
  return (
    <nav className="bg-white shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <Link to="/" className="flex items-center">
              <Coffee className="h-8 w-8 text-accent" />
              <span className="ml-2 text-xl font-serif font-semibold text-primary-900">Savory</span>
            </Link>
          </div>
          
          <div className="hidden md:flex items-center space-x-8">
            <Link to="/" className="text-primary-800 hover:text-accent">Home</Link>
            <Link to="/reserve" className="btn btn-primary">Reserve a Table</Link>
          </div>
          
          <div className="flex md:hidden items-center">
            <button onClick={() => setIsOpen(!isOpen)} className="text-primary-800">
              {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>
      </div>
      
      {isOpen && (
        <div className="md:hidden">
          <div className="pt-2 pb-3 space-y-1 px-4 bg-white">
            <Link to="/" className="block py-2 text-primary-800 hover:text-accent" onClick={() => setIsOpen(false)}>
              Home
            </Link>
            <Link to="/reserve" className="block py-2 text-primary-800 hover:text-accent" onClick={() => setIsOpen(false)}>
              Reserve a Table
            </Link>
          </div>
        </div>
      )}
    </nav>
  );
}
 