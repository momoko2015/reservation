import  { Phone, Mail, MapPin } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-primary-900 text-white">
      <div className="max-w-7xl mx-auto px-4 py-12 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <h3 className="text-lg font-serif font-medium mb-4">Savory Restaurant</h3>
            <p className="text-primary-200 text-sm">Experience the finest dining in an elegant atmosphere</p>
          </div>
          
          <div>
            <h3 className="text-lg font-serif font-medium mb-4">Contact Us</h3>
            <ul className="space-y-2 text-primary-200 text-sm">
              <li className="flex items-center">
                <Phone className="h-4 w-4 mr-2" />
                <span>(555) 123-4567</span>
              </li>
              <li className="flex items-center">
                <Mail className="h-4 w-4 mr-2" />
                <span>contact@savoryrestaurant.com</span>
              </li>
              <li className="flex items-center">
                <MapPin className="h-4 w-4 mr-2" />
                <span>123 Gourmet Avenue, Foodie City</span>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-serif font-medium mb-4">Opening Hours</h3>
            <ul className="space-y-2 text-primary-200 text-sm">
              <li>Monday - Thursday: 11am - 10pm</li>
              <li>Friday - Saturday: 11am - 11pm</li>
              <li>Sunday: 10am - 9pm</li>
            </ul>
          </div>
        </div>
        
        <div className="mt-8 pt-8 border-t border-primary-800 text-center text-primary-200 text-sm">
          <p>&copy; {new Date().getFullYear()} Savory Restaurant. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
 