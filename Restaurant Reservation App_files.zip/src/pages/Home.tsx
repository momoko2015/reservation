import  { Link } from 'react-router-dom';
import { Clock, Users, Calendar } from 'lucide-react';

export default function Home() {
  return (
    <div>
      {/* Hero Section */}
      <div className="relative h-[70vh]">
        <div className="absolute inset-0 bg-black/40 z-10"></div>
        <img 
          src="https://images.unsplash.com/photo-1551632436-cbf8dd35adfa?ixid=M3w3MjUzNDh8MHwxfHNlYXJjaHwxfHxlbGVnYW50JTIwcmVzdGF1cmFudCUyMGludGVyaW9yfGVufDB8fHx8MTc0NDk2MTA0M3ww&ixlib=rb-4.0.3" 
          alt="Elegant restaurant interior" 
          className="absolute inset-0 w-full h-full object-cover"
        />
        <div className="relative z-20 flex flex-col items-center justify-center h-full text-white text-center px-4">
          <h1 className="text-4xl md:text-6xl font-serif font-medium mb-4">Savory Restaurant</h1>
          <p className="text-xl md:text-2xl max-w-2xl mb-8">Experience exceptional dining in an elegant atmosphere</p>
          <Link to="/reserve" className="btn btn-primary py-3 px-8 text-lg">Reserve Your Table</Link>
        </div>
      </div>
      
      {/* Features Section */}
      <div className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-serif font-medium text-center mb-12">Why Choose Us</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="flex flex-col items-center text-center p-6 bg-primary-50 rounded-lg">
              <div className="bg-primary-100 p-3 rounded-full mb-4">
                <Calendar className="h-8 w-8 text-accent" />
              </div>
              <h3 className="text-xl font-medium mb-2">Easy Reservations</h3>
              <p className="text-primary-700">Book your table online in seconds with instant confirmation</p>
            </div>
            
            <div className="flex flex-col items-center text-center p-6 bg-primary-50 rounded-lg">
              <div className="bg-primary-100 p-3 rounded-full mb-4">
                <Users className="h-8 w-8 text-accent" />
              </div>
              <h3 className="text-xl font-medium mb-2">Special Occasions</h3>
              <p className="text-primary-700">Perfect for birthdays, anniversaries, and business meetings</p>
            </div>
            
            <div className="flex flex-col items-center text-center p-6 bg-primary-50 rounded-lg">
              <div className="bg-primary-100 p-3 rounded-full mb-4">
                <Clock className="h-8 w-8 text-accent" />
              </div>
              <h3 className="text-xl font-medium mb-2">Flexible Hours</h3>
              <p className="text-primary-700">Open 7 days a week with extended weekend hours</p>
            </div>
          </div>
        </div>
      </div>
      
      {/* Gallery Section */}
      <div className="py-16 bg-primary-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-serif font-medium text-center mb-12">Our Atmosphere</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <img 
              src="https://images.unsplash.com/photo-1582359324766-9c2e09d83d43?ixid=M3w3MjUzNDh8MHwxfHNlYXJjaHwyfHxlbGVnYW50JTIwcmVzdGF1cmFudCUyMGludGVyaW9yfGVufDB8fHx8MTc0NDk2MTA0M3ww&ixlib=rb-4.0.3" 
              alt="Restaurant interior" 
              className="rounded-lg h-80 w-full object-cover"
            />
            <img 
              src="https://images.unsplash.com/photo-1743793055775-3c07ab847ad0?ixid=M3w3MjUzNDh8MHwxfHNlYXJjaHwzfHxlbGVnYW50JTIwcmVzdGF1cmFudCUyMGludGVyaW9yfGVufDB8fHx8MTc0NDk2MTA0M3ww&ixlib=rb-4.0.3" 
              alt="Elegant table setting" 
              className="rounded-lg h-80 w-full object-cover"
            />
          </div>
          
          <div className="text-center mt-10">
            <Link to="/reserve" className="btn btn-primary py-3 px-8">Make a Reservation</Link>
          </div>
        </div>
      </div>
    </div>
  );
}
 