import  { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { format, addDays } from 'date-fns';
import { useReservation } from '../context/ReservationContext';
import { Calendar, Clock, Users, User, Mail, Phone, FileText } from 'lucide-react';

const timeSlots = [
  '11:00 AM', '11:30 AM', '12:00 PM', '12:30 PM', '1:00 PM', '1:30 PM',
  '2:00 PM', '5:00 PM', '5:30 PM', '6:00 PM', '6:30 PM', '7:00 PM',
  '7:30 PM', '8:00 PM', '8:30 PM', '9:00 PM'
];

export default function Reserve() {
  const { reservation, updateReservation, addReservation } = useReservation();
  const [step, setStep] = useState(1);
  const navigate = useNavigate();
  
  // Generate date options for the next 14 days
  const dateOptions = Array.from({ length: 14 }, (_, i) => {
    const date = addDays(new Date(), i);
    return {
      value: format(date, 'yyyy-MM-dd'),
      label: format(date, 'EEEE, MMMM d, yyyy')
    };
  });
  
  const handleDateTimeSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setStep(2);
  };
  
  const handleFinalSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    addReservation(reservation);
    navigate('/confirmation');
  };
  
  return (
    <div className="py-12 bg-primary-50">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 className="text-3xl font-serif font-medium text-center mb-8">Reserve Your Table</h1>
        
        <div className="bg-white rounded-lg shadow-md p-6 md:p-8">
          {/* Step Indicator */}
          <div className="flex justify-center mb-8">
            <div className="flex items-center">
              <div className={`flex items-center justify-center h-8 w-8 rounded-full ${step >= 1 ? 'bg-accent text-white' : 'bg-primary-200 text-primary-700'}`}>
                1
              </div>
              <div className={`h-1 w-16 ${step >= 2 ? 'bg-accent' : 'bg-primary-200'}`}></div>
              <div className={`flex items-center justify-center h-8 w-8 rounded-full ${step >= 2 ? 'bg-accent text-white' : 'bg-primary-200 text-primary-700'}`}>
                2
              </div>
            </div>
          </div>
          
          {step === 1 ? (
            <form onSubmit={handleDateTimeSubmit}>
              <h2 className="text-xl font-medium mb-6">Select Date & Time</h2>
              
              <div className="mb-4">
                <label className="block text-primary-800 mb-2 flex items-center">
                  <Calendar className="h-5 w-5 mr-2 text-accent" />
                  Date
                </label>
                <select 
                  className="select"
                  value={reservation.date}
                  onChange={(e) => updateReservation({ date: e.target.value })}
                  required
                >
                  <option value="">Select a date</option>
                  {dateOptions.map((option) => (
                    <option key={option.value} value={option.value}>
                      {option.label}
                    </option>
                  ))}
                </select>
              </div>
              
              <div className="mb-4">
                <label className="block text-primary-800 mb-2 flex items-center">
                  <Clock className="h-5 w-5 mr-2 text-accent" />
                  Time
                </label>
                <select 
                  className="select"
                  value={reservation.time}
                  onChange={(e) => updateReservation({ time: e.target.value })}
                  required
                >
                  <option value="">Select a time</option>
                  {timeSlots.map((time) => (
                    <option key={time} value={time}>
                      {time}
                    </option>
                  ))}
                </select>
              </div>
              
              <div className="mb-6">
                <label className="block text-primary-800 mb-2 flex items-center">
                  <Users className="h-5 w-5 mr-2 text-accent" />
                  Number of Guests
                </label>
                <select 
                  className="select"
                  value={reservation.guests}
                  onChange={(e) => updateReservation({ guests: parseInt(e.target.value) })}
                  required
                >
                  {[1, 2, 3, 4, 5, 6, 7, 8].map((num) => (
                    <option key={num} value={num}>
                      {num} {num === 1 ? 'person' : 'people'}
                    </option>
                  ))}
                </select>
              </div>
              
              <button type="submit" className="w-full btn btn-primary py-3">
                Continue
              </button>
            </form>
          ) : (
            <form onSubmit={handleFinalSubmit}>
              <h2 className="text-xl font-medium mb-6">Your Information</h2>
              
              <div className="mb-4">
                <label className="block text-primary-800 mb-2 flex items-center">
                  <User className="h-5 w-5 mr-2 text-accent" />
                  Full Name
                </label>
                <input 
                  type="text" 
                  className="input"
                  value={reservation.name}
                  onChange={(e) => updateReservation({ name: e.target.value })}
                  required
                />
              </div>
              
              <div className="mb-4">
                <label className="block text-primary-800 mb-2 flex items-center">
                  <Mail className="h-5 w-5 mr-2 text-accent" />
                  Email
                </label>
                <input 
                  type="email" 
                  className="input"
                  value={reservation.email}
                  onChange={(e) => updateReservation({ email: e.target.value })}
                  required
                />
              </div>
              
              <div className="mb-4">
                <label className="block text-primary-800 mb-2 flex items-center">
                  <Phone className="h-5 w-5 mr-2 text-accent" />
                  Phone
                </label>
                <input 
                  type="tel" 
                  className="input"
                  value={reservation.phone}
                  onChange={(e) => updateReservation({ phone: e.target.value })}
                  required
                />
              </div>
              
              <div className="mb-6">
                <label className="block text-primary-800 mb-2 flex items-center">
                  <FileText className="h-5 w-5 mr-2 text-accent" />
                  Special Requests (Optional)
                </label>
                <textarea 
                  className="input"
                  rows={3}
                  value={reservation.specialRequests}
                  onChange={(e) => updateReservation({ specialRequests: e.target.value })}
                ></textarea>
              </div>
              
              <div className="flex flex-col md:flex-row gap-4">
                <button 
                  type="button" 
                  className="flex-1 btn btn-outline"
                  onClick={() => setStep(1)}
                >
                  Back
                </button>
                <button type="submit" className="flex-1 btn btn-primary">
                  Complete Reservation
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}
 