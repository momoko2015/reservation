import  { useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { CheckCircle, Calendar, Clock, Users } from 'lucide-react';
import { useReservation } from '../context/ReservationContext';

export default function Confirmation() {
  const { reservation, clearReservation } = useReservation();
  const navigate = useNavigate();
  
  // Redirect if no reservation data
  useEffect(() => {
    if (!reservation.date || !reservation.time) {
      navigate('/reserve');
    }
    
    // Clear reservation on unmount
    return () => {
      clearReservation();
    };
  }, [reservation, navigate, clearReservation]);
  
  if (!reservation.date || !reservation.time) {
    return null;
  }
  
  return (
    <div className="py-12 bg-primary-50">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white rounded-lg shadow-md p-6 md:p-8 text-center">
          <div className="flex justify-center mb-6">
            <CheckCircle className="h-16 w-16 text-green-500" />
          </div>
          
          <h1 className="text-3xl font-serif font-medium mb-4">Reservation Confirmed!</h1>
          <p className="text-primary-700 mb-8">
            Thank you, {reservation.name}. Your table has been reserved.
          </p>
          
          <div className="bg-primary-50 rounded-lg p-6 mb-8 inline-block mx-auto">
            <h2 className="text-xl font-medium mb-4 text-center">Reservation Details</h2>
            
            <div className="flex items-center justify-center mb-3">
              <Calendar className="h-5 w-5 mr-2 text-accent" />
              <span className="text-primary-800">{reservation.date}</span>
            </div>
            
            <div className="flex items-center justify-center mb-3">
              <Clock className="h-5 w-5 mr-2 text-accent" />
              <span className="text-primary-800">{reservation.time}</span>
            </div>
            
            <div className="flex items-center justify-center">
              <Users className="h-5 w-5 mr-2 text-accent" />
              <span className="text-primary-800">
                {reservation.guests} {reservation.guests === 1 ? 'Guest' : 'Guests'}
              </span>
            </div>
          </div>
          
          <p className="text-primary-700 mb-6">
            A confirmation email has been sent to {reservation.email}.<br />
            If you need to make any changes, please call us at (555) 123-4567.
          </p>
          
          <Link to="/" className="btn btn-primary">
            Return to Home
          </Link>
        </div>
      </div>
    </div>
  );
}
 