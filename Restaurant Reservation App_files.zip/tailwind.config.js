/**  @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        primary: {
          50: '#f8f7f4',
          100: '#e8e6df',
          200: '#d5d0c3',
          300: '#bcb29e',
          400: '#a69879',
          500: '#98895f',
          600: '#8c7c4f',
          700: '#776843',
          800: '#63563d',
          900: '#534937',
        },
        accent: '#8B4513',
      },
      fontFamily: {
        sans: ['Inter', 'sans-serif'],
        serif: ['Playfair Display', 'serif'],
      }
    },
  },
  plugins: [],
};
 